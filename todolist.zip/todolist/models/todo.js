const mongoose=require('mongoose')

  const TODOSchema= mongoose.Schema({
    Task:String,
    Checkbox:{type:String,default:'Done'}
   })


module.exports=mongoose.model('TODO',TODOSchema)