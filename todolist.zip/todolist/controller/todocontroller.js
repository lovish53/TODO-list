const TODO=require('../models/todo')

exports.todopage=async(req,res)=>{
   const record= await TODO.find()
     res.render('todopage.ejs',{record})
}

exports.todoform=(req,res)=>{
    res.render('todoform.ejs',{message:''})
}

exports.addtodo=(req,res)=>{
  const {task}=req.body
  const record=new TODO({Task:task})
  record.save()
  res.redirect('/')
}

exports.checkbox=async(req,res)=>{
  const id=req.params.id
  const record=TODO.findById(id)
   await TODO.findByIdAndUpdate(id)
    res.redirect('/')
}

exports.completetask=async(req,res)=>{
  const id=req.params.id
     const record= TODO.findById(id)
     await TODO.findByIdAndUpdate(id,{Checkbox:'Completed'})
     res.redirect('/')

}


exports.deletetask=async(req,res)=>{
   const id=req.params.id
   const record=TODO.findById(id)
    await TODO.findByIdAndDelete(id)
     res.redirect('/')
}


