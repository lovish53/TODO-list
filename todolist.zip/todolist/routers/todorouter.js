const router=require('express').Router()
const todoc=require('../controller/todocontroller')
  

router.get('/',todoc.todopage)
router.get('/taskform',todoc.todoform)
router.post('/taskform',todoc.addtodo)
router.get('/completetask/:id',todoc.completetask)
router.get('/deletetask/:id',todoc.deletetask)

module.exports=router